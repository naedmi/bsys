#include <stdlib.h>
#include <stdio.h>
// int main()
// {
//     int *x = (int *)malloc(sizeof(int));
//     printf("x: %d", *x);
//     return 0;
// }

int main()
{
    int *x = 0;
    int y = *x + 1;
    printf("x: %d", y);
    return 0;
}
// int main()
// {
//     int *x = 0;
//     int y = *x + 1;
//     printf("y: %d", y);
//     return 0;
// }